// frontend/src/App.js
import React from 'react'
import Sidebar from './components/Sidebar'
import ScheduleTableView from './components/ScheduleTableView'

export default function App() {
  return (
    <div className="flex">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="p-4">
          <h1 className="text-2xl font-bold mb-4">Графики смен</h1>
          {/* Здесь позже будет селектор отдела + ViewTabs */}
          <ScheduleTableView departmentId={''} view={'month'} />
        </div>
      </main>
    </div>
  )
}
