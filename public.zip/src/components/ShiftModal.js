// src/components/ShiftModal.js
import React, { useState, useEffect, Fragment } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import axios from 'axios';

export default function ShiftModal({ isOpen, onClose, date, employees, shiftTypes, onSave }) {
  const [selections, setSelections] = useState({});

  useEffect(() => {
    if (!isOpen) return;
    axios.get(`/api/schedules/?month=${date.slice(0,7)}`)
      .then(({ data }) => {
        const init = {};
        data.forEach(empEntry => {
          empEntry.shifts.forEach(s => {
            if (s.date === date) {
              init[empEntry.employee.id] = 
                shiftTypes.find(st => st.name === s.shift_type)?.id || null;
            }
          });
        });
        employees.forEach(emp => {
          if (!(emp.id in init)) init[emp.id] = null;
        });
        setSelections(init);
      })
      .catch(() => {
        const init = {};
        employees.forEach(emp => init[emp.id] = null);
        setSelections(init);
      });
  }, [isOpen, date, employees, shiftTypes]);

  const handleChange = (empId, shiftTypeId) => {
    setSelections(sel => ({ ...sel, [empId]: shiftTypeId }));
  };

  const handleSubmit = () => {
    const entries = Object.entries(selections)
      .filter(([, shiftType]) => shiftType)
      .map(([empId, shiftType]) => ({
        employee: +empId,
        date,
        shift_type: shiftType
      }));
    axios.post('/api/schedules/bulk/', { entries })
      .then(({ data }) => {
        onSave(data);
        onClose();
      });
  };

  return (
    <Transition show={isOpen} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={onClose}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-200"
          enterFrom="opacity-0"
          enterTo="opacity-30"
          leave="ease-in duration-150"
          leaveFrom="opacity-30"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-black" />
        </Transition.Child>

        <div className="fixed inset-0 flex items-center justify-center p-4">
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-200 transform"
            enterFrom="scale-95 opacity-0"
            enterTo="scale-100 opacity-100"
            leave="ease-in duration-150 transform"
            leaveFrom="scale-100 opacity-100"
            leaveTo="scale-95 opacity-0"
          >
            <Dialog.Panel className="bg-white rounded-lg p-6 w-full max-w-lg">
              <Dialog.Title className="text-xl font-bold mb-4">
                Редактировать смены на {date}
              </Dialog.Title>
              <div className="max-h-80 overflow-auto">
                {employees.map(emp => (
                  <div key={emp.id} className="flex items-center mb-2">
                    <div className="w-1/3">{emp.full_name}</div>
                    <select
                      className="border rounded p-1 flex-1"
                      value={selections[emp.id] ?? ''}
                      onChange={e => handleChange(emp.id, e.target.value ? +e.target.value : null)}
                    >
                      <option value="">—</option>
                      {shiftTypes.map(st => (
                        <option key={st.id} value={st.id}>{st.name}</option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>
              <div className="mt-4 flex justify-end space-x-2">
                <button
                  className="px-4 py-2 bg-gray-200 rounded"
                  onClick={onClose}
                >Отмена</button>
                <button
                  className="px-4 py-2 bg-blue-600 text-white rounded"
                  onClick={handleSubmit}
                >Сохранить</button>
              </div>
            </Dialog.Panel>
          </Transition.Child>
        </div>
      </Dialog>
    </Transition>
  );
}
